export const partners = [
  "/images/partners/19.png",
  "/images/partners/20.png",
  "/images/partners/21.png",
  "/images/partners/22.png",
];

export const partnersTwo = [
  "/images/partners/1.png",
  "/images/partners/2.png",
  "/images/partners/3.png",
  "/images/partners/4.png",
  "/images/partners/5.png",
  "/images/partners/6.png",
];

export const header1 = ["/"];
export const header2 = ["/home-2"];
export const header3 = [
  "/register",
  "/login",
  "/become-seller",
  "/contact",
  "/about-1",
  "/about-2",
  "/blog-1",
  "/blog-2",
  "/blog-3",
  "/blog-single",
  "/shop-list",
  "/shop-single",
  "/shop-cart",
  "/shop-checkout",
  "/shop-order",
  "/service-1",
  "/service-2",
  "/service-3",
  "/service-4",
  "/service-5",
  "/service-6",
  "/service-7",
  "/service-all",
  "/service-single",
  "/service-single-v2",
  "/service-single-v3",

  "/project-1",
  "/project-2",
  "/project-3",
  "/project-4",
  "/project-single",
  "/project-single-v2",
  "/project-single-v3",
  "/job-1",
  "/job-2",
  "/job-3",
  "/job-single",
  "/employee-1",
  "/employee-2",
  "/employee-single",
  "/freelancer-1",
  "/freelancer-2",
  "/freelancer-3",
  "/freelancer-single",
  "/freelancer-single-v2",
  "/freelancer-single-v3",
  "/faq",
  "/help",
  "/pricing",
  "/terms",
  "/ui-elements",
];
export const header4 = ["/home-3"];
export const header5 = ["/home-4"];
export const header6 = ["/home-5"];
export const header7 = ["/home-6"];
export const header8 = ["/home-7"];
export const header9 = ["/home-8"];
export const header10 = ["/home-9"];
export const header11 = ["/home-10"];
export const header12 = ["/home-11"];

export const sidebarEnable = [
  "/service-1",
  "/service-2",
  "/service-3",
  "/service-4",
  "/service-5",
  "/service-6",
  "/service-7",
  "/project-1",
  "/project-2",
  "/project-3",
  "/project-4",
  "/job-1",
  "/job-2",
  "/job-3",
  "/employee-1",
  "/employee-2",
  "/freelancer-1",
  "/freelancer-2",
  "/freelancer-3",
];

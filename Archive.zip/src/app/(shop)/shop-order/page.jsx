import OrderComplete1 from "@/components/element/OrderComplete1";


export const metadata = {
  title: "Freeio - Freelance Marketplace React/Next Js Template | Shop Order",
};

export default function page() {
  return (
    <>
    
      <OrderComplete1 />
    </>
  );
}

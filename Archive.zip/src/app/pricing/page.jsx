
import PriceTable1 from "@/components/section/PriceTable1";

export const metadata = {
  title: "Freeio - Freelance Marketplace React/Next Js Template | Pricing",
};

export default function page() {
  return (
    <>
    
      <PriceTable1 />
    </>
  );
}
